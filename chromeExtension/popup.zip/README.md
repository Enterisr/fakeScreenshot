# Photo Uploader Chrome Extension

This is a simple Chrome extension that lets you:

1. Pick a photo from the popup.
2. Preview it locally.
3. Upload it to an external server with a `POST` request.

## Install locally

1. Open `chrome://extensions`.
2. Turn on Developer mode.
3. Click Load unpacked.
4. Select this folder.

## How it works

- Choose an image file.
- Click Send photo.

The extension sends the file as `multipart/form-data` under the field name `photo`.
The upload endpoint is configured in `popup.js` via the `UPLOAD_ENDPOINT` constant.

## Notes

- No server is included here.
- Update `UPLOAD_ENDPOINT` in `popup.js` to point at your server.
